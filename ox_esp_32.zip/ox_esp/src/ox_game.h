// Oxide: Survival Island state reader (read-only): local camera + every PlayerManager the client knows.
#pragma once
#include "code.h"
#include "il2cpp.h"
#include "vmath.h"
#include <map>
#include <string>
#include <vector>

struct OxPlayer {
    uint32_t id = 0;
    Vec3 pos, vel;
    bool local = false, dead = false;
    int hp = 100;
    char name[32] = {0};
    uint64_t obj = 0;        // PlayerManager* (for silent aim target selection; not sent over the protocol)
};

struct SilentCfg {
    bool on = false;
    int bone = 0;             // 0 head, 1 body, 2 legs
    float fovDeg = 6.f;       // half-angle around the camera forward a target must fall inside
    float maxDist = 300.f;
};

struct OxSnap {
    Cam cam;
    std::vector<OxPlayer> players;
};

class OxGame {
public:
    OxGame(IMem& m, uint64_t il2cppBase) : m_(m), il_(m, il2cppBase) {}
    bool update(OxSnap& s, float fovY);          // false -> status() says why
    // silent aim: redirects FPHitscan's fire ray to a chosen bone of a chosen target, inside fovDeg of the crosshair; reversible, off() falls back to real aim
    void silent_prepare(bool wanted);
    void silent_feed(const SilentCfg& c, const OxSnap& s);
    const char* silent_status() const { return silentStatus_.c_str(); }
    void patch_recoil(bool noRecoil);               // zeroes the local weapon's accumulated recoil state every tick (data-only, no code patch)
    const char* recoil_status() const { return recoilStatus_.c_str(); }
    // zeroes the local PlayerManager's own speedhack/flyhack telemetry counters every tick (data-only write, no
    // code patch, no position write -- see offsets.h PlayerManager anti-cheat block for exactly what this does
    // and doesn't do). Needs the current snapshot to find the local player's object.
    void patch_anticheat(bool enable, const OxSnap& s);
    const char* anticheat_status() const { return acStatus_.c_str(); }
    // EXPERIMENTAL: writes GameModes.thirdPersonMode = Forced on the live GameModes instance (heap-found, same
    // pattern as the recoil patch). Forced's int value is an inference (see offsets.h), not confirmed -- this may
    // do nothing, may not survive a server resync, or may be the wrong number entirely. Test and report.
    void patch_thirdperson(bool enable);
    const char* thirdperson_status() const { return tpStatus_.c_str(); }
    // writes the local player's own max health into whichever Health backing offset (+0x20/+0x24 on the Entity's
    // Health wrapper object) read_hp() found valid -- same wrapper object and same ambiguity read_hp already
    // resolves, just written back instead of only read.
    void patch_godmode(bool enable, const OxSnap& s);
    const char* godmode_status() const { return gmStatus_.c_str(); }
    // zeroes m_DepletionRate on the local PlayerVitals' Thirst/Hunger/Oxygen StatDepleter objects every tick --
    // direct pointer deref off vitals, no heap scan needed (see offsets.h Vitals/StatDepleter).
    void patch_noneeds(bool enable, const OxSnap& s);
    const char* noneeds_status() const { return needsStatus_.c_str(); }
    // clamps local PlayerVitals.temperature to 37 (normal) and zeroes radiationLevel/radiationPoison every tick --
    // plain inline floats on vitals, no indirection.
    void patch_noenv(bool enable, const OxSnap& s);
    const char* noenv_status() const { return envStatus_.c_str(); }
    void shutdown_patches();
    const char* status() const { return status_.c_str(); }
    std::string diag() const { return diag_; }
    int classes_seen() const { return il_.classes_seen(); }
    // Unity native Transform chain of a managed Component: world position + rotation (x,y,z,w); validated by the caller
    bool comp_trs(uint64_t component, Vec3& pos, float q[4]);
private:
    bool nat_trs(uint64_t nativeTransform, Vec3& pos, float q[4]);
    static constexpr int NC = 6;
    int pos_cands(uint64_t pm, Vec3 out[NC], bool ok[NC], uint64_t* kccOut);
    std::string nick(uint64_t pm);
    struct CS { Vec3 last[6]; double t[6] = {0, 0, 0, 0, 0, 0}, chg[6] = {0, 0, 0, 0, 0, 0}; int sel = -1; };
    std::map<uint64_t, CS> cs_;
    uint64_t kFPH_ = 0, fireFunc_ = 0;
    const char* fireCandidateUsed_ = "";
    CodePatcher code_{m_};
    RayHook ray_{m_, code_};
    bool rayOk_ = false;
    std::string silentStatus_ = "off";
    double nextSilent_ = 0;
    uint64_t hitscanObj_ = 0;     // live FPHitscan instance found by heap scan, not a guessed offset chain
    double nextHitscanScan_ = 0;
    std::string recoilStatus_ = "off";
    std::string acStatus_ = "off";
    uint64_t kGM_ = 0, gmObj_ = 0;
    double nextGmScan_ = 0;
    std::string tpStatus_ = "off";
    std::string gmStatus_ = "off";
    std::string needsStatus_ = "off";
    std::string envStatus_ = "off";
    uint64_t kccCache_ = 0;
    bool read_hp(uint64_t vitals, int& hp, std::string& name);
    IMem& m_;
    Il2 il_;
    uint64_t kPM_ = 0, pmStatics_ = 0;
    std::string status_ = "init", diag_;
    struct Track { Vec3 pos; double t = 0; Vec3 vel; };
    std::map<uint64_t, Track> tr_;
    std::vector<uint64_t> heap_;
    double nextScan_ = 0;
};
