// ox_dumper: standalone, root, read-only runtime dumper for il2cpp games.
//
// Why this exists: every dump the user has supplied so far has turned out to be the wrong version (filename
// didn't match what was actually installed, or the dump predated a patch). The .so and global-metadata.dat
// SITTING ON DISK can also be scrambled on purpose by some protections (packers that keep the real metadata
// encrypted in the APK and only decrypt it into memory at runtime -- "the jammer" in the user's words) so even
// pulling the on-disk file and running Il2CppDumper against it gives garbage or nothing. The fix for both
// problems is the same: dump straight out of the LIVE process's memory, after il2cpp has already loaded and
// (if it was encrypted) decrypted everything -- this is Il2CppDumper's own documented "memory dump" input mode,
// not a new trick; we're just doing the memory read ourselves (same /proc/pid/mem access ox_core already uses,
// no injection, no code execution in the target) instead of asking for a file off disk.
//
// Output: <pkg>.libil2cpp.so.dump and <pkg>.global-metadata.dat.dump in the given directory. Feed BOTH into
// Il2CppDumper, choose "memory dump" mode when it asks (it detects this automatically for most versions, or
// there's an explicit prompt depending on the Il2CppDumper build) -- it fixes up the vaddr/fileoffset mismatch
// a memory-mapped image always has versus an on-disk ELF. Don't rename the files or run them through anything
// else first.
#include "mem.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <unistd.h>

static bool write_file(const std::string& path, const std::vector<uint8_t>& data) {
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t w = fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return w == data.size();
}

// dumps [start,end) from `m` in chunks, zero-filling any unreadable page (IMem::read already zeroes on failure,
// so a protected/unmapped sub-range just comes back as zeros instead of aborting the whole dump)
static std::vector<uint8_t> dump_range(IMem& m, uint64_t start, uint64_t end) {
    std::vector<uint8_t> out;
    if (end <= start) return out;
    out.resize((size_t)(end - start));
    const size_t chunk = 1 << 20;
    for (size_t off = 0; off < out.size(); off += chunk) {
        size_t n = std::min(chunk, out.size() - off);
        m.read(start + off, out.data() + off, n);
    }
    return out;
}

// Il2Cpp global-metadata header sanity signature, little-endian bytes AF 1B B1 FA at offset 0 of the file/region.
static bool looks_like_metadata(const std::vector<uint8_t>& buf) {
    return buf.size() >= 4 && buf[0] == 0xAF && buf[1] == 0x1B && buf[2] == 0xB1 && buf[3] == 0xFA;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("usage: ox_dumper <pkg-substring[,pkg2,...]> [outdir]\n");
        return 1;
    }
    if (getuid() != 0) { printf("needs root\n"); return 1; }
    std::string pkgs = argv[1];
    std::string outdir = argc > 2 ? argv[2] : ".";

    Proc proc;
    int pid = 0;
    std::string pkgExact;
    size_t a = 0;
    while (!pid && a <= pkgs.size()) {
        size_t b = pkgs.find(',', a);
        if (b == std::string::npos) b = pkgs.size();
        if (b > a) pid = Proc::find_pid(pkgs.substr(a, b - a), pkgExact);
        a = b + 1;
    }
    if (!pid) { printf("process not found for '%s' -- is the game running?\n", pkgs.c_str()); return 1; }
    if (!proc.attach(pid)) { printf("attach failed pid=%d\n", pid); return 1; }
    printf("attached pid=%d pkg=%s\n", pid, pkgExact.c_str());

    auto regions = proc.regions();

    // ---- libil2cpp.so: contiguous flat dump from its lowest mapped address to its highest ----
    uint64_t soLo = UINT64_MAX, soHi = 0;
    for (auto& r : regions) {
        if (r.path.find("libil2cpp.so") == std::string::npos) continue;
        soLo = std::min(soLo, r.start);
        soHi = std::max(soHi, r.end);
    }
    if (soLo == UINT64_MAX) {
        printf("libil2cpp.so: not mapped in this process (wrong pid, or it hasn't loaded yet)\n");
    } else {
        auto img = dump_range(proc, soLo, soHi);
        std::string path = outdir + "/" + pkgExact + ".libil2cpp.so.dump";
        bool ok = write_file(path, img);
        printf("libil2cpp.so: base=0x%llx size=%zu -> %s (%s)\n",
               (unsigned long long)soLo, img.size(), path.c_str(), ok ? "ok" : "write_failed");
    }

    // ---- global-metadata.dat: prefer the file-backed mapping (normal case) ----
    uint64_t metaStart = 0, metaEnd = 0;
    std::string metaSrc;
    for (auto& r : regions) {
        if (r.path.find("global-metadata.dat") == std::string::npos) continue;
        if (metaStart == 0 || r.start < metaStart) metaStart = r.start;
        metaEnd = std::max(metaEnd, r.end);
    }
    if (metaStart) metaSrc = "file-backed mapping";

    // Fallback: the protection decrypts metadata into an anonymous region instead of keeping a file-backed
    // mapping visible -- scan every r/w anon region for the header signature at offset 0 of some page. This is
    // the actual "bypass the jammer" step: whatever hid the on-disk file, the decrypted bytes still have to
    // exist in memory for il2cpp to read them, so they're findable the same way scan_all() finds Il2CppClass
    // self-pointers elsewhere in this codebase -- a fixed byte signature, not a guess about this specific game.
    if (!metaStart) {
        std::vector<uint8_t> page(4096);
        for (auto& r : regions) {
            if (!r.r || !r.w) continue;
            if (!r.path.empty() && r.path[0] != '[') continue;          // anon / [heap] / [anon:...] only
            if (r.end - r.start > (512ull << 20)) continue;             // metadata files run a few MB to tens of MB, not hundreds
            for (uint64_t p = r.start; p < r.end; p += 4096) {
                if (!proc.read(p, page.data(), 4)) continue;
                if (looks_like_metadata(page)) { metaStart = p; metaEnd = r.end; metaSrc = "anon-scan @0x" ; break; }
            }
            if (metaStart) break;
        }
    }

    if (!metaStart) {
        printf("global-metadata.dat: not found (neither file-backed nor by signature scan) -- can't produce it this run\n");
    } else {
        auto img = dump_range(proc, metaStart, metaEnd);
        // trim to the declared string-literal/header size if sane, else ship the whole containing region --
        // Il2CppDumper only reads what its header says it needs, trailing junk is harmless.
        std::string path = outdir + "/" + pkgExact + ".global-metadata.dat.dump";
        bool ok = write_file(path, img);
        printf("global-metadata.dat: start=0x%llx size=%zu src=%s -> %s (%s)\n",
               (unsigned long long)metaStart, img.size(), metaSrc.c_str(), path.c_str(), ok ? "ok" : "write_failed");
    }

    proc.detach();
    return 0;
}
