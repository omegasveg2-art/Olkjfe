// In-process memory access for the injected build: same IMem interface as mem.h's Proc (external, /proc/pid/mem),
// but reads/writes are direct pointer dereferences in our own address space -- no syscalls, no IPC round trip.
// Game object pointers are still untrusted (garbage offsets, freed objects), so every access goes through a
// SIGSEGV/SIGBUS-guarded memcpy: a bad dereference is caught and reported as a failed read, not a crash of the
// host process we're injected into. install_fault_guard() must run once (from the injected lib's entry point)
// before any LocalMem use.
#pragma once
#include "mem.h"
#include <cstdint>
#include <cstring>

// Installs the SIGSEGV/SIGBUS handler LocalMem relies on. Call once, early, from the injected .so's constructor.
// Chains to any previously-installed handler for signals that didn't originate from a guarded access (so we don't
// swallow a real crash elsewhere in the host process).
void install_fault_guard();

class LocalMem : public IMem {
public:
    bool read(uint64_t addr, void* out, size_t n) override;
    bool write(uint64_t addr, const void* in, size_t n) override;    // mprotects the page(s) RW+X first, never restores (cave pages stay RWX)
    std::vector<Region> regions() override;                          // parses /proc/self/maps
};
