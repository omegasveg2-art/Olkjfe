// ox_core: root, read-only memory reader for Oxide: Survival Island. Talks to the overlay APK over stdin/stdout.
// out:  S|ok|cx,cy,cz|fx,fy,fz|fovY|0|id,team,hp,flags,x,y,z,vx,vy,vz,name;...|info|0,0,0,0,0,-1,0     or   N|status
// in:   C|fov=70,maxd=300,pkg...   (partial lines are fine)
#include "ox_game.h"
#include <algorithm>
#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <unistd.h>

static std::mutex g_mu;
static volatile bool g_quit = false;
static void on_signal(int) { g_quit = true; }
static float g_fov = 70.f, g_maxd = 400.f;
static SilentCfg g_sil;
static bool g_noRecoil = false;
static bool g_noFlags = false;
static bool g_thirdPerson = false;
static bool g_godMode = false;
static bool g_noNeeds = false;
static bool g_noEnv = false;

static void stdin_loop() {
    char line[1024];
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] != 'C' || line[1] != '|') continue;
        char* save = nullptr;
        for (char* t = strtok_r(line + 2, ",\r\n", &save); t; t = strtok_r(nullptr, ",\r\n", &save)) {
            char* eq = strchr(t, '=');
            if (!eq) continue;
            *eq = 0;
            float v = strtof(eq + 1, nullptr);
            std::lock_guard<std::mutex> l(g_mu);
            if (!strcmp(t, "fov")) g_fov = v; else if (!strcmp(t, "maxd")) g_maxd = v;
            else if (!strcmp(t, "sil")) g_sil.on = v != 0; else if (!strcmp(t, "sbone")) g_sil.bone = (int)v;
            else if (!strcmp(t, "sfov")) g_sil.fovDeg = v; else if (!strcmp(t, "smaxd")) g_sil.maxDist = v;
            else if (!strcmp(t, "norecoil")) g_noRecoil = v != 0;
            else if (!strcmp(t, "noflags")) g_noFlags = v != 0;
            else if (!strcmp(t, "tp")) g_thirdPerson = v != 0;
            else if (!strcmp(t, "god")) g_godMode = v != 0;
            else if (!strcmp(t, "noneeds")) g_noNeeds = v != 0;
            else if (!strcmp(t, "noenv")) g_noEnv = v != 0;
        }
    }
    g_quit = true;
}

static std::string clean(const char* s) {
    std::string o;
    for (; *s; s++) o.push_back((isalnum((unsigned char)*s) || *s == '_' || *s == '.' || *s == '-' || *s == ' ') ? *s : '_');
    return o;
}

int main(int argc, char** argv) {
    std::string pkgs = "oxide,hyperhug";
    uint64_t baseOverride = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-p") && i + 1 < argc) pkgs = argv[++i];
        else if (!strcmp(argv[i], "--base") && i + 1 < argc) baseOverride = strtoull(argv[++i], nullptr, 16);
    }
    if (getuid() != 0) { printf("N|needs root\n"); return 1; }
    setvbuf(stdout, nullptr, _IOLBF, 0);
    signal(SIGTERM, on_signal); signal(SIGINT, on_signal); signal(SIGHUP, on_signal); signal(SIGPIPE, SIG_IGN);
    std::thread(stdin_loop).detach();

    Proc proc;
    OxGame* game = nullptr;
    OxSnap snap;
    std::string status = "waiting for game";
    std::string pkgExact;                 // exact package id, captured at attach, for the PlayerPrefs read below
    float realFov = 0.f;                  // 0 = not resolved yet this session -> fall back to g_fov
    auto lastTry = std::chrono::steady_clock::now() - std::chrono::seconds(10);
    auto lastFovCheck = std::chrono::steady_clock::now() - std::chrono::seconds(10);
    for (;;) {
        if (g_quit) { if (game) game->shutdown_patches(); return 0; }
        if (game && !proc.alive()) { game->shutdown_patches(); delete game; game = nullptr; proc.detach(); status = "game closed"; }
        if (!game && std::chrono::steady_clock::now() - lastTry > std::chrono::seconds(2)) {
            lastTry = std::chrono::steady_clock::now();
            int pid = 0;
            size_t a = 0;
            while (!pid && a <= pkgs.size()) {
                size_t b = pkgs.find(',', a);
                if (b == std::string::npos) b = pkgs.size();
                if (b > a) pid = Proc::find_pid(pkgs.substr(a, b - a), pkgExact);
                a = b + 1;
            }
            if (pid) {
                proc.attach(pid);
                uint64_t base = baseOverride ? baseOverride : proc.module_base("libil2cpp.so");
                if (base) game = new OxGame(proc, base);
                else { proc.detach(); status = "libil2cpp.so not mapped"; }
                realFov = 0.f; lastFovCheck = std::chrono::steady_clock::now() - std::chrono::seconds(10);   // force a fresh read on (re)attach
            }
        }
        if (!game) { printf("N|%s\n", status.c_str()); std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }
        // real fov lives in the game's own PlayerPrefs (Settings > Graphics > FOV, confirmed key "fov" from the
        // il2cpp dump) -- read it off disk, not off the config slider. Re-checked every 3s in case the player
        // tabs out and changes it mid-session. Falls back to g_fov only if the file/key truly isn't there yet.
        static std::string g_fovWhy = "no_pkg";
        if (!pkgExact.empty() && std::chrono::steady_clock::now() - lastFovCheck > std::chrono::seconds(3)) {
            lastFovCheck = std::chrono::steady_clock::now();
            float v = read_unity_pref_float(pkgExact, "fov", 0.f, g_fovWhy);
            if (v > 1.f && v < 179.f) realFov = v;   // sane vertical-fov range only; 0/garbage -> keep last good value
            else if (g_fovWhy == "ok") g_fovWhy = "out_of_range(" + std::to_string(v) + ")";
        }
        float fov, maxd;
        { std::lock_guard<std::mutex> l(g_mu); fov = realFov > 0.f ? realFov : g_fov; maxd = g_maxd; }
        if (!game->update(snap, fov)) { game->silent_prepare(false); printf("N|%s\n", game->status()); std::this_thread::sleep_for(std::chrono::milliseconds(150)); continue; }
        SilentCfg sil; bool noRecoil, noFlags, tp, god, noNeeds, noEnv;
        { std::lock_guard<std::mutex> l(g_mu); sil = g_sil; noRecoil = g_noRecoil; noFlags = g_noFlags; tp = g_thirdPerson; god = g_godMode; noNeeds = g_noNeeds; noEnv = g_noEnv; }
        game->silent_prepare(sil.on);
        game->silent_feed(sil, snap);
        game->patch_recoil(noRecoil);
        game->patch_anticheat(noFlags, snap);
        game->patch_thirdperson(tp);
        game->patch_godmode(god, snap);
        game->patch_noneeds(noNeeds, snap);
        game->patch_noenv(noEnv, snap);
        std::string out = "S|ok|";
        char b[320];
        snprintf(b, sizeof b, "%.3f,%.3f,%.3f|%.4f,%.4f,%.4f|%.2f|0|", snap.cam.pos.x, snap.cam.pos.y, snap.cam.pos.z, snap.cam.fwd.x, snap.cam.fwd.y, snap.cam.fwd.z, snap.cam.fovY);
        out += b;
        bool first = true;
        for (auto& p : snap.players) {
            if (!p.local && len(p.pos - snap.cam.pos) > maxd) continue;
            snprintf(b, sizeof b, "%s%u,0,%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,", first ? "" : ";", p.id, p.hp, (p.local ? 1 : 0) | (p.dead ? 2 : 0), p.pos.x, p.pos.y, p.pos.z, p.vel.x, p.vel.y, p.vel.z);
            out += b; out += clean(p.name[0] ? p.name : "Player");
            first = false;
        }
        out += "|" + game->diag() + " sil=" + game->silent_status() + " rec=" + game->recoil_status() +
               " ac=" + game->anticheat_status() + " tp=" + game->thirdperson_status() + " god=" + game->godmode_status() +
               " needs=" + game->noneeds_status() + " env=" + game->noenv_status() +
               " fov=" + (realFov > 0.f ? "real" : ("fallback:" + g_fovWhy)) + " pkg=" + pkgExact + "|0,0,0,0,0,-1,0\n";
        if (fputs(out.c_str(), stdout) < 0) return 0;
        std::this_thread::sleep_for(std::chrono::milliseconds(8));
    }
}
